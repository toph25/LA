import sys
a = str(sys.argv[1])
if a.lower() == 'jeryl abong':
	print " Motivated"
else:
	print " ooop"